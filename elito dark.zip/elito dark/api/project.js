


const Projects = [
    {
       Id:'1',
       pImg:'images/project/img-1.jpg',
       ps1img:'images/project-single/img-1.jpg',
       psub1img1:'images/project-single/p1.jpg',
       psub1img2:'images/project-single/p2.jpg',
       title:'Arkio - Architecture & Interior WordPress Theme',  
       subTitle:'Architecture / Business',   
    },
    {
       Id:'2',
       pImg:'images/project/img-2.jpg',
       ps1img:'images/project-single/img-2.jpg',
       psub1img1:'images/project-single/p1.jpg',
       psub1img2:'images/project-single/p2.jpg',
       title:'Follio - Multipurpose Portfolio HTML5 Template', 
       subTitle:'Web Design',    
    },
    {
      Id:'3',
      pImg:'images/project/img-3.jpg',
      ps1img:'images/project-single/img-3.jpg',
      psub1img1:'images/project-single/p1.jpg',
      psub1img2:'images/project-single/p2.jpg',
      title:'Elito - Creative Portfolio React Template',  
      subTitle:'Website / Creative',   
   },
   {
      Id:'4',
      pImg:'images/project/img-2.jpg',
      ps1img:'images/project-single/img-2.jpg',
      psub1img1:'images/project-single/p1.jpg',
      psub1img2:'images/project-single/p2.jpg',
      title:'Follio - Multipurpose Portfolio HTML5 Template', 
      subTitle:'Web Design',    
   },
   
    
]

export default Projects;